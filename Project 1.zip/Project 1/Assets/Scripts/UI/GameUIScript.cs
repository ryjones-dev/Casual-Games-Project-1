﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class GameUIScript : MonoBehaviour {

    private Canvas canvas;

    public Text timer;
    public float timeInitial = 70;
    public Text goal;

    public Text score;
    public Text scoreQuota;

    public GameObject progressBar;

    private int timerMinutes;
    private int timerSeconds;
    private float timeRemaining;

    private GameManager gm;

	// Use this for initialization
	void Start () {
        timeRemaining = timeInitial;
        gm = GameManager.instance;
	}
	
	// Update is called once per frame
	void Update () {
        if (!gm.gamePaused)
        {
            if (timeRemaining > 0)
            {
                timeRemaining -= Time.deltaTime;
                if (timeRemaining < 0) { timeRemaining = 0; }
                UpdateTimer();
            }
        }
	}

    //updates timer UI to show time remaining in the user-friendly minute:second format
    private void UpdateTimer()
    {
        timerMinutes = (int)timeRemaining / 60;
        timerSeconds = (int)timeRemaining % 60;
        string secondstring = "" + timerSeconds;
        if (timerSeconds < 10) { secondstring = "0" + secondstring; }
        timer.text = timerMinutes + ":" + secondstring;
    }
}
